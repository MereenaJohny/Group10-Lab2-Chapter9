# Fundamentals of Web Development, 2nd Edition
### Chapter 9 [JavaScript 2], Project 1 [Art]
You will demonstrate your ability to respond to events, select and modify elements
via the DOM, and to validate form data.

  
